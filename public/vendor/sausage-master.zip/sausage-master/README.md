A jQuery UI widget for contextual pagination.

For details, see [http://christophercliff.github.com/sausage](http://christophercliff.github.com/sausage).